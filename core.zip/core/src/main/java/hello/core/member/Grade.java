package hello.core.member;

public enum Grade {
    BASIC,
    VIP
}
